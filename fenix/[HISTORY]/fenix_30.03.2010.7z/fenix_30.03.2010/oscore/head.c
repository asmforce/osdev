void osentry()
{
  osmain();
};

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_IO
#define FENIX_IO

#define BCDToBin(value)  ( (value) = ( (value) & 15 ) + ( (value) >> 4 ) * 10 )

void inline o( u8 value, u16 port )
{
  asm __volatile__ ( "outb %%al, %%dx"::"a"((u8) value),"d"((u16) port) );
};

u32 inline i( u16 port )
{
  u32 value;
  asm __volatile__ ( "inb %%dx, %%al":"=a"(value):"d"((u16) port),"0"(0) );
  return value;
};

#endif

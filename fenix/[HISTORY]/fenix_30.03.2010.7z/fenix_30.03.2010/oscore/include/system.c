/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_SYSTEM
#define FENIX_SYSTEM


#define cli()    asm("CLI")
#define sti()    asm("STI")
#define nop()    asm("NOP")
#define hlt()    asm("HLT")
#define iret()   asm("IRET")
#define iretd()  asm(".WORD 0xCF66");
#define reboot() asm( "MOV $0xFE, %AL\n"   \
                      "OUT %AL, $0x64\n"   \
                      "MARK: JMP MARK" )

#define cpuid( _eax_, _ebx_, _ecx_, _edx_ )  asm("CPUID":"=a"(_eax_),"=b"(_ebx_),"=c"(_ecx_),"=d"(_edx_):"a"(_eax_))

#define random( range )  ( (i(0x40) | (i(0x40)<<16)) % (range) )

#endif

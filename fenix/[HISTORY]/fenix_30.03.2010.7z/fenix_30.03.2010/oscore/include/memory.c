/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_MEMORY
#define FENIX_MEMORY


char *ramcpy( char *to, const char *from, unsigned n )
{
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "andl $3, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep movsd\n\t"
      "movl %%ebx, %%ecx\n\t"
      "rep movsb"
      ::"S" (from), "D" (to), "c" (n) );
  return to;
};

char *ramset( char *to, unsigned c, unsigned n )
{
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "andl $3, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep stosl\n\t"
      "movl %%ebx, %%ecx\n\t"
      "rep stosb"
      ::"D" (to), "a" (c), "c" (n) );
  return to;
};

i8 inline memcmp( const void *to, const void *from, u32 n )
{
  asm("cld\n\t"
      "repe cmpsb\n\t"
      :"=S" (from), "=D" (to)
      :"S" (from), "D" (to), "c" (n) );
  return *((i8*)from-1) - *((i8*)to-1);
};

#endif

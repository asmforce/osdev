/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CONSOLE
#define FENIX_CONSOLE


#define SCREEN_HEIGHT 25
#define SCREEN_WIDTH 80

#define VIDEO_TEXT_BEG  0xB8000
#define VIDEO_TEXT_END  ((VIDEO_TEXT_BEG + (SCREEN_WIDTH * SCREEN_HEIGHT)) * 2 + 1)
#define VIDEO_GRAPH_BEG 0xA0000

typedef struct
{
  u8 character;
  u8 color;
} ScreenCharacter;



ScreenCharacter *videomem = (ScreenCharacter*) VIDEO_TEXT_BEG;
static u16 xpos = 0;
static u16 ypos = 0;



void outc( tchar c )
{
  if( xpos == SCREEN_WIDTH ) 
  {
    xpos = 0;
    ++ypos;
  };
  switch( c )
  {
  case '\n':
    ++ypos;
  case '\r':
    xpos = 0;
    break;

  case '\t':
    videomem[ ypos * SCREEN_WIDTH + xpos ].character = ' ';
    ++xpos;
    videomem[ ypos * SCREEN_WIDTH + xpos ].character = ' ';
    ++xpos;
    videomem[ ypos * SCREEN_WIDTH + xpos ].character = ' ';
    ++xpos;
    break;

  case '\b':
    if( xpos )
    {
      --xpos;
      videomem[ ypos * SCREEN_WIDTH + xpos ].character = ' ';
    };
    break;

  default:
    videomem[ ypos * SCREEN_WIDTH + xpos ].character = c;
    ++xpos;
  };
};


void outcs( const tchar *cs )
{
  while( *cs )
  {
    if( xpos == SCREEN_WIDTH ) 
    {
      xpos = 0;
      ++ypos;
    };
    if( *cs == '\n' )
    {
      xpos = 0;
      ++ypos;
    } else {
      videomem[ ypos * SCREEN_WIDTH + xpos ].character = *cs;
      ++xpos;
    };
    ++cs;
  };
};

#endif

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CMOS
#define FENIX_CMOS


// BYTE BCD -> BIN
#define  BCDToBin8( value )           \
(                                     \
  ( ((value) & 0xF0) >> 4  ) * 10 +   \
  (  (value) & 0x0F        )          \
)

// BYTE BIN -> BCD
#define  BinToBCD8( value )                   \
(                                             \
  ((value) % 10) | ((((value)/10) % 10) << 4) \
)

u8 icmos( u8 cell )
{
  o( cell, 0x70 );
  nop();
  return i( 0x71 );
};

void ocmos( u8 cell, u8 value )
{
  o( cell, 0x70 );
  nop();
  o( value, 0x71 );
};


#endif

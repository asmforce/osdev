/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_STRING
#define FENIX_STRING



inline u32 strlen( const tchar *cs )
{
  u32 n;
  asm("cld\n\t"
      "xorl %%eax, %%eax\n\t"
      "xorl %%ecx, %%ecx\n\t"
      "notl %%ecx\n\t"
      "repne scasb\n\t"
      "notl %%ecx\n\t"
      "decl %%ecx\n\t"
      : "=c" (n)
      : "D"  (cs) );
  return n;
};

inline tchar *strcpy( tchar *to, const tchar *from )
{
  asm("cld\n\t"
      "repnz movsb\n\t"
      :"=D"(to)
      :"S" (from), "D" (to), "c" (0xFFFFFFFF) );
  return to;
};

inline tchar *strncpy( tchar *to, const tchar *from, u32 n )
{
  asm("cld\n\t"
      "repnz movsb\n\t"
      :"=D"(to)
      :"S" (from), "D" (to), "c" (n) );
  return to;
};


static tchar ___buffer[33] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '\0' };

const tchar *utocs( u32 num, u8 radix )
{
  tchar *cs = ___buffer + 31;
  u16 rem;
  do
  {
    rem = num % radix;
    if( rem < 10 )
    {
      *cs = rem + '0';
    } else {
      *cs = rem + 'A' - 10;
    };
    --cs;
  } while( num /= radix );
  return ++cs;
};

const tchar *itocs( i32 num, u8 radix )
{
  bool negative = false;
  if( num < 0 )
  {
    negative = true;
    num = -num;
  };


  tchar *cs = ___buffer + 31;
  u16 rem;
  do
  {
    rem = num % radix;
    if( rem < 10 )
    {
      *cs = rem + '0';
    } else {
      *cs = rem + 'A' - 10;
    };
    --cs;
  } while( num /= radix );

  if( negative )
  {
    *cs = '-';
    return cs;
  };
  return ++cs;
};

#endif

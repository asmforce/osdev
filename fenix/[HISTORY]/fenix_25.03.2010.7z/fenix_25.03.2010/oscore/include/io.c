/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_IO
#define FENIX_IO

#define BCDToBin(value)  ( (value) = ( (value) & 15 ) + ( (value) >> 4 ) * 10 )

void inline o( i8 value, u16 port )
{
  __asm__ __volatile__ ( "outb %%al,%%dx"::"a" ((i8) value),"d" ((u16) port) );
}

u32 inline i( u16 port )
{
  u32 value;
  __asm__ __volatile__ ( "inb %%dx,%%al":"=a" (value):"d" ((u16) port),"0" (0) );
  return value;
}

#endif

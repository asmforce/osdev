/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_SYSTEM
#define FENIX_SYSTEM


#define cli()    asm("CLI")
#define sti()    asm("STI")
#define nop()    asm("NOP")
#define hlt()    asm("HLT")
#define iret()   asm("IRET")
#define iretd()  asm(".WORD 0xCF66");
#define reboot() asm( "MOV $0xFE, %AL\n"   \
                      "OUT %AL, $0x64\n"   \
                      "MARK: JMP MARK" )


#endif

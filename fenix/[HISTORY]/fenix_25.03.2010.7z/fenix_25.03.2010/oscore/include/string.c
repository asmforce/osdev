/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_STRING
#define FENIX_STRING

u32 cslen( const tchar *cs )
{
  u32 begin = (u32)cs;
  while( *cs )  ++cs;
  return (u32)cs - begin;
};

u32 cscopy( tchar *dcs, const tchar *scs )
{
  u32 begin = (u32)scs;
  while( *scs )
  {
    *dcs = *scs;
    ++dcs;
    ++scs;
  };
  return (u32)scs - begin;
};

static tchar u32tocs_buffer[11] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '\0' };
const tchar *u32tocs( u32 num, u16 radix )
{
  tchar *buffer = u32tocs_buffer+9;
  u16 ost;
  do
  {
    ost = num % radix;
    if( ost < 10 )
    {
      *buffer = ost + '0';
    } else {
      *buffer = ost + 'A' - 10;
    };
    --buffer;
  } while( num /= radix );
  ++buffer;
  return buffer;
};

#endif

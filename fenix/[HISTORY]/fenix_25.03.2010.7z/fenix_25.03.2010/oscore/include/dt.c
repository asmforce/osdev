/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_DT
#define FENIX_DT

typedef struct
{
  union
  {
    struct { u32 a32,            b32;            };
    struct { u16 a16,    b16,    c16,    d16;    };
    struct { u8  a8, b8, c8, d8, e8, f8, g8, h8; };
  };
} IDTDesc, GDTDesc, LDTDesc;


typedef struct
{
  u16       size;
  IDTDesc  *table;
} IDTReg;

#endif

#pragma pack(1)
//asm(".intel_syntax noprefix\n");
//gcc -masm-intel
#include "include/aliases.c"
#include "include/io.c"
#include "include/dt.c"
#include "include/system.c"
#include "include/console.c"
#include "include/string.c"



#define  BCDToBin8( value ) ( (value) = (                                       \
                                          (  (value) & 0x00F0) >> 4  ) * 10 +   \
                                          (  (value) & 0x000F        )          \
                                        )                                       \
                            )


#define BCDToBin16( value ) ( (value) = (                                         \
                                          ( ((value) & 0xF000) >> 12 ) * 1000 +   \
                                          ( ((value) & 0x0F00) >> 8  ) * 100 +    \
                                          ( ((value) & 0x00F0) >> 4  ) * 10 +     \
                                          (  (value) & 0x000F        )            \
                                        )                                         \
                            )


#define BCDToBin32( value ) ( (value) = (                                              \
                                          ( ((value) & 0xF000) >> 32 ) * 100000000 +   \
                                          ( ((value) & 0x0F00) >> 28 ) * 10000000 +    \
                                          ( ((value) & 0xF000) >> 24 ) * 1000000 +     \
                                          ( ((value) & 0x0F00) >> 20 ) * 100000 +      \
                                          ( ((value) & 0x00F0) >> 16 ) * 10000 +       \
                                          ( ((value) & 0xF000) >> 12 ) * 1000 +        \
                                          ( ((value) & 0x0F00) >> 8  ) * 100 +         \
                                          ( ((value) & 0x00F0) >> 4  ) * 10 +          \
                                          (  (value) & 0x000F        )                 \
                                        )                                              \
                            }

/*

#define  BinToBCD8( value ) ( (value) = (                                  \
                                          ( ((value) & 0x00F0) >> 4  ) +   \
                                          (  (value) & 0x000F)       )     \
                                        )


#define BinToBCD16( value ) ( (value) = (                                  \
                                          ( ((value) & 0xF000) >> 12 ) +   \
                                          ( ((value) & 0x0F00) >> 8  ) +   \
                                          ( ((value) & 0x00F0) >> 4  ) +   \
                                          (  (value) & 0x000F)       )     \
                                        )


#define BinToBCD32( value ) ( (value) = (                                  \
                                          ( ((value) & 0xF000) >> 32 ) +   \
                                          ( ((value) & 0x0F00) >> 28 ) +   \
                                          ( ((value) & 0xF000) >> 24 ) +   \
                                          ( ((value) & 0x0F00) >> 20 ) +   \
                                          ( ((value) & 0x00F0) >> 16 ) +   \
                                          ( ((value) & 0xF000) >> 12 ) +   \
                                          ( ((value) & 0x0F00) >> 8  ) +   \
                                          ( ((value) & 0x00F0) >> 4  ) +   \
                                          (  (value) & 0x000F)       )     \
                                        )
*/
union CPURegs
{
  struct
  {
    u32 eax;
    u32 ebx;
    u32 edx;
    u32 ecx;
  };
  struct
  {
    u16 ax;
    u16 ax_h;
    u16 bx;
    u16 bx_h;
    u16 dx;
    u16 dx_h;
    u16 cx;
    u16 cx_h;
  };
  struct
  {
    u8 al;
    u8 ah;
    u8 al_h;
    u8 ah_h;
    u8 bl;
    u8 bh;
    u8 bl_h;
    u8 bh_h;
    u8 dl;
    u8 dh;
    u8 dl_h;
    u8 dh_h;
    u8 cl;
    u8 ch;
    u8 cl_h;
    u8 ch_h;
  };
};

#define CPUID( regs )  asm("CPUID":"=a"(regs.eax),"=b"(regs.ebx),"=c"(regs.ecx),"=d"(regs.edx):"a"(regs.eax))
#define TestBit( value, bit )  ( value & (1 << bit) )




void osmain()
{
  // � ���� 0x21 ����� 0xFF, �������� ��� ���������� (���������� IRQx ������������� ��� x)
  o( 0xFF, 0x21 );

  union CPURegs regs;

  regs.eax = 0;
  CPUID( regs );

  outcs("CPU Vendor: ");
  outcs( &regs.bl );

  regs.eax = 1;
  CPUID( regs );

  if( TestBit(regs.edx,0) )   outcs("00 - FPU Supported\n");
  if( TestBit(regs.edx,1) )   outcs("01 - V86 Extended. VIP, VIF at EFLAGS\n");
  if( TestBit(regs.edx,2) )   outcs("02 - Extended debug. Break on i/o\n");
  if( TestBit(regs.edx,3) )   outcs("03 - Page size 4MB supperted\n");
  if( TestBit(regs.edx,4) )   outcs("04 - RDTSC Supported\n");
  if( TestBit(regs.edx,5) )   outcs("05 - Model-specific registers\n");
  if( TestBit(regs.edx,6) )   outcs("06 - 36bits physical address\n");
  if( TestBit(regs.edx,7) )   outcs("07 - Machine Check Exception Supported\n");
  if( TestBit(regs.edx,8) )   outcs("08 - CMPXCHG8B\n");
  if( TestBit(regs.edx,9) )   outcs("09 - APIC\n");
  if( TestBit(regs.edx,10) )  outcs("10 - [RESERVED]\n");
  if( TestBit(regs.edx,11) )  outcs("11 - SYSENTER, SYSEXIT (AMD: SYSCALL, SYSRET)\n");
  if( TestBit(regs.edx,12) )  outcs("12 - MTRR Cache control registers\n");
  if( TestBit(regs.edx,13) )  outcs("13 - Paging globality bit\n");
  if( TestBit(regs.edx,14) )  outcs("14 - Machine Control Architecture\n");
  if( TestBit(regs.edx,15) )  outcs("15 - CMOVxx\n");
  if( TestBit(regs.edx,16) )  outcs("16 - Page attributes\n");
  if( TestBit(regs.edx,17) )  outcs("17 - Paging PSE-36\n");
  if( TestBit(regs.edx,18) )  outcs("18 - CPU-Serial Supported\n");
  if( TestBit(regs.edx,19) )  outcs("19 - CLFLUSH\n");
  if( TestBit(regs.edx,20) )  outcs("20 - [RESERVED]\n");
  if( TestBit(regs.edx,21) )  outcs("21 - Debug jumping history\n");
  if( TestBit(regs.edx,22) )  outcs("22 - ACPI (MMX)\n");
  if( TestBit(regs.edx,23) )  outcs("23 - MMX\n");
  if( TestBit(regs.edx,24) )  outcs("24 - FPU Context saving/loading supported\n");
  if( TestBit(regs.edx,25) )  outcs("25 - SSE\n");
  if( TestBit(regs.edx,26) )  outcs("26 - SSE2\n");
  if( TestBit(regs.edx,27) )  outcs("27 - Self Snoop\n");
  if( TestBit(regs.edx,28) )  outcs("28 - [RESERVED]\n");
  if( TestBit(regs.edx,29) )  outcs("29 - Antihot\n");
  if( TestBit(regs.edx,30) )  outcs("30 - Extended AMD 3Dnow!\n");
  if( TestBit(regs.edx,31) )  outcs("31 - AMD 3Dnow! Supported\n");

  outcs("\n[asmforce os fenix]\n");

  u32  value;
  do
  {
    xpos = 0;

    outc('[');
    o( 4, 0x70 );
    value = i( 0x71 );
    outcs( u32tocs(BCDToBin16(value),10) );
    outcs( ":" );

    o( 2, 0x70 );
    value = i( 0x71 );
    outcs( u32tocs(BCDToBin16(value),10) );
    outcs( ":" );

    o( 0, 0x70 );
    value = i( 0x71 );
    outcs( u32tocs(BCDToBin16(value),10) );
    outcs("]   ");

    //hlt();
  } while( true );

  //while(1)  hlt();
};

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CMOS_C
#define FENIX_CMOS_C

#include "../include/aliases.h"
#include "../include/asm.h"
#include "../include/io.h"
#include "../include/cmos.h"

u8 rdCmos( u8 cell )
{
  wio8( cell, 0x70 );
  nop();
  return rio8( 0x71 );
};

void wrCmos( u8 cell, u8 value )
{
  wio8( cell, 0x70 );
  nop();
  wio8( value, 0x71 );
};

#endif

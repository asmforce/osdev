/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CONSOLE_C
#define FENIX_CONSOLE_C

#include "../include/aliases.h"
#include "../include/console.h"

static ScreenCharacter *videomem;


static inline void ramset( void *to, u32 c, u32 n )
{
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep stosl\n\t"
      "movl %%ebx, %%ecx\n\t"
      "andl $3, %%ecx\n\t"
      "rep stosb"
      ::"D" (to), "a" (c), "c" (n) );
};






void initConsole( u8 color )
{
  videomem = (ScreenCharacter *) VIDEOMEM_TEXT;
  ramset( videomem, 0x00200020 | (u32)color << 24 | (u32)color << 8, SCREEN_TEXT_HEIGHT * SCREEN_TEXT_WIDTH << 1 );
};


void clearLine( u8 color )
{
  videomem -= (((u32) videomem - VIDEOMEM_TEXT) >> 1) % SCREEN_TEXT_WIDTH;
  ramset( videomem, 0x00200020 | (u32)color << 24 | (u32)color << 8, SCREEN_TEXT_WIDTH << 1 );
};


void printc( tchar c )
{
  switch( c )
  {
    case '\n':
      videomem += SCREEN_TEXT_WIDTH;
    case '\r':
      videomem -= (((u32) videomem - VIDEOMEM_TEXT) >> 1) % SCREEN_TEXT_WIDTH;
      return;

    case '\t':
      videomem += 3;
      return;

    case '\b':
      --videomem;
      videomem->character = ' ';
      return;

    default:
      videomem->character = c;
      ++videomem;
      return;
  };
};

void prints( const tchar *cs )
{
  while( *cs )
  {
    printc( *cs );
    ++cs;
  };
};


#endif

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_RTC_C
#define FENIX_RTC_C

#include "../include/aliases.h"
#include "../include/utility.h"
#include "../include/console.h"
#include "../include/cmos.h"
#include "../include/rtc.h"

tchar *weekDayNames[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

void readRtc( DateTime *datetime )
{
  datetime->year    = BCDToBin8(rdCmos( 0x32 )) * 100;    // ��� � BCD �������
  datetime->year   += rdCmos( 0x09 );

  datetime->month   = rdCmos( 0x08 );
  datetime->day     = rdCmos( 0x07 );

  datetime->weekDay = rdCmos( 0x06 );

  datetime->hour    = rdCmos( 0x04 );
  datetime->minute  = rdCmos( 0x02 );
  datetime->second  = rdCmos( 0x00 );
};

#endif

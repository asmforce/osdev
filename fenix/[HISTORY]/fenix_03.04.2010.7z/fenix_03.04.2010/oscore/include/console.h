/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CONSOLE_H
#define FENIX_CONSOLE_H

#include "aliases.h"

#define SCREEN_TEXT_HEIGHT 25
#define SCREEN_TEXT_WIDTH  80

#define VIDEOMEM_TEXT  0xB8000
#define VIDEOMEM_GRAPH 0xA0000

typedef struct
{
  u8 character;
  u8 color;
} ScreenCharacter;

void initConsole( u8 color );
#define clearScreen( color )  initConsole( color )
void clearLine( u8 color );

void printc( tchar c );
void prints( const tchar *cs );

#endif

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_IO_H
#define FENIX_IO_H

#include "aliases.h"

static void inline wio8( u8 value, u16 port )
{
  asm __volatile__ ( "outb %%al, %%dx" :: "a"(value),"d"( port) );
};

static void inline wio16( u16 value, u16 port )
{
  asm __volatile__ ( "outw %%ax, %%dx" :: "a"(value),"d"(port) );
};

static void inline wio32( u32 value, u16 port )
{
  asm __volatile__ ( "outl %%eax, %%dx" :: "a" (value), "d" (port) );
};



static u8 inline rio8( u16 port )
{
  u8 value;
  asm __volatile__ ( "inb %%dx, %%al" : "=a" (value) : "d" (port) );
  return value;
};

static u16 inline rio16( u16 port )
{
  u16 value;
  asm __volatile__ ( "inw %%dx, %%ax" : "=a" (value) : "d" (port) );
  return value;
};

static u32 inline rio32( u16 port )
{
  u32 value;
  asm __volatile__ ( "inl %%dx, %%eax" : "=a" (value) : "d" (port) );
  return value;
};

#endif

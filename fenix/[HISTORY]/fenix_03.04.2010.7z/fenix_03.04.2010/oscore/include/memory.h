/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_MEMORY_H
#define FENIX_MEMORY_H

#include "aliases.h"

/*
#define WordFromBytes( b1, b2 )           ((b2) | ((u16)(b1)<<8))
#define DWordFromBytes( b1, b2, b3, b4 )  ((b4) | ((u32)(b3)<<8) | ((u32)(b2)<<16) | ((u32)(b1)<<24))
#define DWordFromWords( w1, w2 )          ((w2) | ((u32)(w1)<<16))
*/

static inline void *ramcpy( void *to, const void *from, u32 n )
{
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep movsd\n\t"
      "movl %%ebx, %%ecx\n\t"
      "andl $3, %%ecx\n\t"
      "rep movsb"
      ::"S" (from), "D" (to), "c" (n) );
  return to;
};

static inline void *ramset( void *to, u8 c, u32 n )
{
  u32 num = c;
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep stosl\n\t"
      "movl %%ebx, %%ecx\n\t"
      "andl $3, %%ecx\n\t"
      "rep stosb"
      ::"D" (to), "a" (num | (num << 8) | (num << 16) | (num << 24)), "c" (n) );
  return to;
};

static inline i8 ramcmp( const void *to, const void *from, u32 n )
{
  asm("cld\n\t"
      "repe cmpsb\n\t"
      :"=S" (from), "=D" (to)
      :"S" (from), "D" (to), "c" (n) );
  return *((i8*)from-1) - *((i8*)to-1);
};

#endif

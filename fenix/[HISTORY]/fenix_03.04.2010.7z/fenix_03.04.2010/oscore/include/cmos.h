/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CMOS_H
#define FENIX_CMOS_H

#include "aliases.h"
#include "io.h"

u8 rdCmos( u8 cell );
void wrCmos( u8 cell, u8 value );

#endif

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/

#pragma pack(1)
//asm(".intel_syntax noprefix\n");
//gcc -masm-intel

#include "include/aliases.h"

#include "include/asm.h"
#include "include/io.h"

#include "include/systables.h"
#include "include/gates.h"

#include "include/string.h"
#include "include/memory.h"

#include "include/timers.h"
#include "include/cmos.h"
#include "include/clock.h"

#include "include/console.h"
#include "include/ide.h"








void dump( u32 base, u32 n )
{
  disableInt();
  u8 *p = (u8*) base;
  u32 i;
  for( i = 0; i != n; ++i )
  {
    prints( u32ToString(p[i],16) );
    printc( ' ' );
  };
  printc( '\n' );
  enableInt();
};








tchar *keyNames[] = { "",          "ESC",       "1",         "2",         "3",         "4",         "5",         "6",         "7",         "8",
                      "9",         "0",         "-",         "=",         "Backspace", "Tab",       "q",         "w",         "e",         "r",
                      "t",         "y",         "u",         "i",         "o",         "p",         "[",         "]",         "Enter",     "Ctrl",
                      "a",         "s",         "d",         "f",         "g",         "h",         "j",         "k",         "l",         ";",
                      "\'",        "`",         "LShift",    "\\",        "z",         "x",         "c",         "v",         "b",         "n",
                      "m",         ",",         ".",         "/",         "RShift",    "PrtSc",     "Alt",       "Space",     "CapsLk",    "F1",
                      "F2",        "F3",        "F4",        "F5",        "F6",        "F7",        "F8",        "F9",        "F10",       "Pause",
                      "F12",       "71",        "Up",        "73",        "74",        "Left",      "76",        "Right",     "78",        "79",
                      "Down",      "81",        "Insert",    "Delete",    "84",        "85",        "86",        "F11",       "F12",       "89",
                      "90",        "WinKey",    "92",        "WinMenu",   "94",        "95",        "Switch-96", "97",        "98",        "99",
                      "100",       "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE" };

tchar *keyShiftedNames[] = { "",          "ESC",       "!",         "@",         "#",         "$",         "%",         "^",         "&",         "*",
                             "(",         ")",         "_",         "+",         "Backspace", "Tab",       "Q",         "W",         "E",         "R",
                             "T",         "Y",         "U",         "I",         "O",         "P",         "{",         "}",         "Enter",     "Ctrl",
                             "A",         "S",         "D",         "F",         "G",         "H",         "J",         "K",         "L",         ":",
                             "\"",        "~",         "LShift",    "|",         "Z",         "X",         "C",         "V",         "B",         "N",
                             "M",         "<",         ">",         "?",         "RShift",    "PrtSc",     "Alt",       "Space",     "CapsLk",    "F1",
                             "F2",        "F3",        "F4",        "F5",        "F6",        "F7",        "F8",        "F9",        "F10",       "Pause",
                             "F12",       "71",        "Up",        "73",        "74",        "Left",      "76",        "Right",     "78",        "79",
                             "Down",      "81",        "Insert",    "Delete",    "84",        "85",        "86",        "F11",       "F12",       "89",
                             "90",        "WinKey",    "92",        "WinMenu",   "94",        "95",        "Switch-96", "97",        "98",        "99",
                             "100",       "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE" };



void doOnTimer()
{
};

extern void onTimer();

__asm__("_onTimer:          \n"    // IRQ0
	"pusha              \n"
	"pushf              \n"
	"call _doOnTimer    \n"
	"popf               \n"
	"popa               \n"
	"iret");








static u8 shiftState = 0;
void doOnKeyboard( u8 scancode )
{
  //u8 value = rdio8( 0x60 );

  switch( scancode & 0x7F )
  {
  case 1:
    machineReboot();

  case 83:
    clearScreen( 0x04 );

  case 42:
  case 54:
    shiftState = !(scancode & 0x80);
    return;

  default:
    if( scancode & 0x80 )  return;
    prints( shiftState ? keyShiftedNames[scancode] : keyNames[scancode] );
  };
};

extern void onKeyboard();

__asm__("_onKeyboard:       \n"    // IRQ1
	"pusha              \n"
	"pushf              \n"
	"xor %eax, %eax     \n"
	"inb $0x60, %al     \n"
	"push %eax          \n"
	"call _doOnKeyboard \n"
	"pop %eax           \n"
	"popf               \n"
	"popa               \n"
	"iret");






void doOnDivideError()
{
  prints( "<divbyzero>" );
};

extern void onDivideError();

























void initSystem()
{
  // ��� �� ������ �����, ��� ��������� ����������� ���������� IRQ
  wrio8( 0x00, 0x21 ); // 0x21 - ������� ���������� ����������
  wrio8( 0x00, 0xA1 ); // 0xA1 - ������� ���������� ����������

  // �������������� ������, ������������ ������� ��������� RAM
  initRam();

  // ������� initGates() �������������� idttable
  initGates(); 

  // ����� �� ������������� ����������� ����������
  //setTrapGate( &onDivideError, 0 );
  setIntrGate( &onTimer, 32 );
  setIntrGate( &onKeyboard, 33 );

  // ������������� ������ � ��������
  initTimer0( 3, 0xFFFF );
  initTimer2( 3, 0xFFFF );

  // ��� ������� �������������� �������:
  // ������������� ��������� �� �����������,
  // ������� �����, �������� ��� ������� �������
  // ������� - �������� �������
  initConsole( 0x04 );

  // ��� ������� �������������� ���� ��������� �������:
  // �������� ����� bin ������ bcd, � 24�-������� ������
  initClock();
};







typedef struct
{
  u16 link;
  unsigned:16;

  u32 esp0;
  u16 ss0;
  unsigned:16;

  u32 esp1;
  u16 ss1;
  unsigned:16;

  u32 esp2;
  u16 ss2;
  unsigned:16;

  u32 cr3;
  u32 eip;
  u32 eflags;

  u32 eax;
  u32 ecx;
  u32 edx;
  u32 ebx;

  u32 esp;
  u32 ebp;
  u32 esi;
  u32 edi;

  u16 es;
  unsigned:16;
  u16 cs;
  unsigned:16;
  u16 ss;
  unsigned:16;
  u16 ds;
  unsigned:16;
  u16 fs;
  unsigned:16;
  u16 gs;
  unsigned:16;

  u16 ldtr;
  unsigned:16;

  unsigned debug:1;
  unsigned:15;
  u16 iomap;
} Tss;




void traceLoop()
{
  static tchar *to = (tchar*) 0xB8000;
  static tchar *progress = "-\\|/";
  u16 i = 0;

  while( 1 )
  {
    if( !progress[i] )  i = 0;
    *to = progress[i];
    ++i;

    waitInt();
    waitInt();
    waitInt();
    waitInt();
  };
};








void osmain()
{
  initSystem();

  prints("---------------------------------[OS Fenix (c)]---------------------------------\n");
  printf( "ram:$u\n", memoryTotal );

  enableInt();
  traceLoop();
  while(1)  waitInt();
};

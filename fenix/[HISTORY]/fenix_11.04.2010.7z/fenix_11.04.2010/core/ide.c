/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_IDE_C
#define FENIX_IDE_C

#include "../include/aliases.h"
#include "../include/io.h"
#include "../include/ide.h"


#define ReadReg( channel, register )          rdio8( channel + register )
#define WriteReg( channel, register, value )  wrio8( value, channel + register )

#define ChannelCli( channel )      WriteReg( channel, IDERegControl, 0x02 )
#define ChannelSti( channel )      WriteReg( channel, IDERegControl, 0x00 )
#define ResetController( channel ) WriteReg( channel, IDERegControl, 0x0F )

//#define CHANNELS_NUMBER 4
//bool channelFree[CHANNELS_NUMBER];






static inline bool waitWhileBusy( IDEChannel channel )
{
  u16 retries = 1000;
  while( ReadReg(channel,IDERegStatus) & IDEStatusBusy && --retries );
  return retries;
};

static inline bool waitUntilReady( IDEChannel channel )
{
  u16 retries = 1000;
  while( !(ReadReg(channel,IDERegStatus) & IDEStatusReady) && --retries );
  return retries;
};

static inline bool waitUntilDrq( IDEChannel channel )
{
  u16 retries = 1000;
  while( !(ReadReg(channel,IDERegStatus) & IDEStatusDrq) && --retries );
  return retries;
};








IDEError ideReadSector( void *buffer, IDEChannel channel, IDEDrive drive, u32 sector )
{
  ChannelCli( channel );

  if( !waitWhileBusy(channel) )  return IDEErrorTimeOut;

  WriteReg( channel, IDERegNSec, 1 );
  WriteReg( channel, IDEReg0Sec, sector & 0x000000FF );
  WriteReg( channel, IDEReg1Sec, (sector & 0x0000FF00) >> 8 );
  WriteReg( channel, IDEReg2Sec, (sector & 0x00FF0000) >> 16 );
  WriteReg( channel, IDEReg3Sec, 0xE0 | ((sector & 0x0F000000)>>24) | ((drive & 0x1)<<4) );

  if( !waitWhileBusy(channel) )  return IDEErrorTimeOut;
  if( !waitUntilReady(channel) )  return IDEErrorTimeOut;

  WriteReg( channel, IDERegCommand, IDECmdRead );

  if( !waitWhileBusy(channel) )  return IDEErrorTimeOut;
  if( !waitUntilDrq(channel) )  return IDEErrorTimeOut;
  if( (ReadReg(channel,IDERegStatus) & IDEStatusError) )
  {
    u8 error = ReadReg( channel, IDERegError );
    ResetController( channel );
    return error;
  };

  asm("cld \n\t rep \t insw" :: "d" (channel + IDERegData), "c" (0x100), "D" (buffer) );

  ChannelSti( channel );
  return 0;
};

IDEError ideWriteSector( const void *buffer, IDEChannel channel, IDEDrive drive, u32 sector )
{
  ChannelCli( channel );

  if( !waitWhileBusy(channel) )  return IDEErrorTimeOut;

  WriteReg( channel, IDERegNSec, 1 );
  WriteReg( channel, IDEReg0Sec, sector & 0x000000FF );
  WriteReg( channel, IDEReg1Sec, (sector & 0x0000FF00) >> 8 );
  WriteReg( channel, IDEReg2Sec, (sector & 0x00FF0000) >> 16 );
  WriteReg( channel, IDEReg3Sec, 0xE0 | ((sector & 0x0F000000)>>24) | ((drive & 0x1)<<4) );

  if( !waitWhileBusy(channel) )  return IDEErrorTimeOut;
  if( !waitUntilReady(channel) )  return IDEErrorTimeOut;

  WriteReg( channel, IDERegCommand, IDECmdWrite );

  if( !waitWhileBusy(channel) )  return IDEErrorTimeOut;
  if( !waitUntilDrq(channel) )  return IDEErrorTimeOut;
  if( (ReadReg(channel,IDERegStatus) & IDEStatusError) )
  {
    u8 error = ReadReg( channel, IDERegError );
    ResetController( channel );
    return error;
  };

  asm("cld \n\t rep \t outsw" :: "d" (channel + IDERegData), "c" (0x100), "S" (buffer) );

  ChannelSti( channel );
  return 0;
};

#endif

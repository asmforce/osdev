#ifndef RP_ELF_H
#define RP_ELF_H	"Written by Red Plait, 13-II-2000"

typedef unsigned short Elf_word;
typedef unsigned long Elf_dword;

#define EI_NIDENT	16

struct Elf32_Hdr {
  unsigned char e_ident[EI_NIDENT];
  Elf_word		e_type;
  Elf_word		e_machine;
  Elf_dword		e_version;
  Elf_dword		e_entry;
  Elf_dword		e_phoff;
  Elf_dword		e_shoff;
  Elf_dword		e_flags;
  Elf_word		e_ehsize;
  Elf_word		e_phentsize;
  Elf_word		e_phnum;
  Elf_word		e_shentsize;
  Elf_word		e_shnum;
  Elf_word		e_shstrndx;
};

#define EI_MAG0		e_ident[0]
#define EI_MAG1		e_ident[1]
#define EI_MAG2		e_ident[2]
#define EI_MAG3		e_ident[3]
#define EI_CLASS	e_ident[4]
#define EI_DATA		e_ident[5]
#define EI_VERSION	e_ident[6]
#define EI_PAD		e_ident[7]

#define ELFMAG0		0x7f
#define ELFMAG1		'E'
#define ELFMAG2		'L'
#define ELFMAG3		'F'

#define EM_NONE		0
#define EM_M32		1
#define EM_SPARC	2
#define EM_386		3
#define EM_68K		4
#define EM_88K		5
#define EM_860		7
#define EM_MIPS		8

struct Elf_phdr {
 Elf_dword		p_type;
 Elf_dword		p_offset;
 Elf_dword		p_vaddr;
 Elf_dword		p_paddr;
 Elf_dword		p_filesz;
 Elf_dword		p_memsz;
 Elf_dword		p_flags;
 Elf_dword		p_align;
};

struct Elf_shdr {
 Elf_dword		sh_name;
 Elf_dword		sh_type;
 Elf_dword		sh_flags;
 Elf_dword		sh_addr;
 Elf_dword		sh_off;
 Elf_dword		sh_size;
 Elf_dword		sh_link;
 Elf_dword		sh_info;
 Elf_dword		sh_addralign;
 Elf_dword		sh_entsize;
};

/* for sh_type */
#define SHT_NULL		0
#define SHT_PROGBITS	1
#define SHT_SYMTAB		2
#define SHT_STRTAB		3
#define SHT_RELA		4
#define SHT_HASH		5
#define SHT_DYNAMIC		6
#define SHT_NOTE		7
#define SHT_NOBITS		8
#define SHT_REL			9
#define SHT_SHLIB		10
#define SHT_DYNSYM		11

/* for sh_flags */
#define SHF_WRITE		1
#define SHF_ALLOC		2
#define SHF_EXECINSTR	4

/* program header p_type */
#define PT_NULL		0
#define PT_LOAD		1
#define PT_DYNAMIC	2
#define PT_INTERP	3
#define PT_NOTE		4
#define PT_SHLIB	5
#define PT_PHDR		6

/* memory flags */
#define PF_R		0x4
#define PF_W		0x2
#define PF_X		0x1

#endif /* RP_ELF_H */
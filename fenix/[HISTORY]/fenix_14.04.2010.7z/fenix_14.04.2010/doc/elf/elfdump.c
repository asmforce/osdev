#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "elf.h"

/* ELF dump
 * Red Plait (redplait@usa.net) 6-IV-2000
 */

const char *elf_types[] = {
	"Relocatable file",
	"Executable file",
	"Shared object file",
	"Core file"
};

int
main(int argc, char **argv)
{
	FILE *fp;
	struct Elf32_Hdr hdr;
	struct Elf_phdr phdr;
	unsigned long shstr_off = 0L;

	if ( argc != 2 )
	{
		fprintf(stderr, "Usage: elfdump <filename>\n");
		exit(1);
	}
	if ( NULL == (fp = fopen(argv[1], "rb")) )
	{
		fprintf(stderr, "Cannot open %s, errno = %d\n", argv[1], errno);
		exit(2);
	}
	if ( sizeof(hdr) != fread(&hdr, 1, sizeof(hdr), fp) )
	{
		fprintf(stderr, "Error reading of elf header\n");
		fclose(fp);
		exit(3);
	}
	/* check for signature */
	if ( hdr.EI_MAG0 != ELFMAG0 ||
		 hdr.EI_MAG1 != ELFMAG1 ||
		 hdr.EI_MAG2 != ELFMAG2 ||
		 hdr.EI_MAG3 != ELFMAG3 )
	{
		fprintf(stderr, "Bad signature\n");
		fclose(fp);
		exit(3);
	}
	/* check for class */
	if ( hdr.EI_CLASS == 2 )
	{
		fprintf(stderr, "64bit ELF dont supported (yet)\n");
		fclose(fp);
		exit(3);
	}
	if ( hdr.EI_CLASS != 1 )
	{
		fprintf(stderr, "Unknown EI_CLASS %d\n", hdr.EI_CLASS);
		fclose(fp);
		exit(3);
	}
	/* check for data encoding */
	if ( hdr.EI_DATA != 1 &&
		 hdr.EI_DATA != 2 )
	{
		fprintf(stderr, "Bad EI_DATA %d\n", hdr.EI_DATA);
		fclose(fp);
		exit(3);
	}
	printf("Data encoding: %s\n", hdr.EI_DATA == 2 ? "MSB" : "LSB" );
	if ( hdr.EI_DATA != 1 )
	{
		fprintf(stderr, "LSB data encoding not supported (yet)\n");
		fclose(fp);
		exit(3);
	}
	printf("Elf version: %d\n", hdr.EI_VERSION );
	/* check for e_type */
	if ( hdr.e_type < 1 || hdr.e_type > 4 )
	{
		fprintf(stderr, "Unknown e_type %d\n", hdr.e_type);
		fclose(fp);
		exit(3);
	}
	printf("e_type: %s\n", elf_types[hdr.e_type-1]);
	printf("e_machine: %d\n", hdr.e_machine);
	printf("e_flags: 0x%X\n", hdr.e_flags);
	printf("e_version: %d\n", hdr.e_version);
	printf("e_entry: 0x%X\n", hdr.e_entry);
	printf("e_ehsize %d (must be %d)\n", hdr.e_ehsize, sizeof(hdr) );
	printf("e_phentsize %d (must be %d)\n", hdr.e_phentsize, sizeof(struct Elf_phdr) );
	printf("e_shentsize %d (must be %d)\n", hdr.e_shentsize, sizeof(struct Elf_shdr) );
	printf("e_phnum %d, e_phoff 0x%X\n", hdr.e_phnum, hdr.e_phoff );
	printf("e_shnum %d, e_shoff 0x%X\n", hdr.e_shnum, hdr.e_shoff );
	printf("e_shstrndx: %d\n", hdr.e_shstrndx);
	/* program headerz */
	if ( hdr.e_phnum )
	{
		int i;
		fseek(fp, hdr.e_phoff, SEEK_SET);
		printf("Program headers\n");
		for ( i = 0; i < hdr.e_phnum; i++ )
		{
			fread(&phdr, 1, sizeof(phdr), fp);
			printf("[%d]\n", i);
			printf("p_type: %d\n", phdr.p_type);
			printf("p_offset: 0x%X\n", phdr.p_offset);
			printf("p_vaddr: 0x%X\n", phdr.p_vaddr);
			printf("p_paddr: 0x%X\n", phdr.p_paddr);
			printf("p_filesz: 0x%X\n", phdr.p_filesz);
			printf("p_memsz: 0x%X\n", phdr.p_memsz);
			printf("p_flags: 0x%X\n", phdr.p_flags);
			printf("p_align: 0x%X\n", phdr.p_align);
		}
	}
	/* section headerz */
	if ( hdr.e_shnum )
	{
		struct Elf_shdr str_shdr, shdr;
		int i;
		unsigned long tel, next_addr;

		fseek(fp, hdr.e_shoff + hdr.e_shentsize * hdr.e_shstrndx, SEEK_SET);
		fread(&str_shdr, 1, sizeof(str_shdr), fp);
		if ( str_shdr.sh_type != SHT_STRTAB )
		{
			printf("Warning: e_shstrndx(%d) points to section with type %d\n",
				hdr.e_shstrndx, str_shdr.sh_type );
		} else
		{
			shstr_off = str_shdr.sh_off;
		}
		fseek(fp, hdr.e_shoff, SEEK_SET);
		printf("Section headers\n");
		for ( i = 0; i < hdr.e_shnum; i++ )
		{
			fread(&shdr, 1, sizeof(shdr), fp);
			tel = ftell(fp);
			printf("[%d]\n", i);
			/* name */
			printf("sh_name: %d ", shdr.sh_name);
			if ( shstr_off )
			{
				char buffer[256];
				fseek(fp, shstr_off + shdr.sh_name, SEEK_SET);
				fgets(buffer,255, fp);
				printf("(%s)", buffer);
				fseek(fp,tel,SEEK_SET);
			}
			printf("\n");
			/* type */
			printf("sh_type: %d\n", shdr.sh_type);
			/* flags */
			printf("sh_flags: 0x%X\n", shdr.sh_flags);
			/* addr */
			printf("sh_addr: 0x%X\n", shdr.sh_addr);
			/* offset */
			printf("sh_offset: 0x%X\n", shdr.sh_off);
			/* size */
			next_addr = shdr.sh_off + shdr.sh_size;
			/* in next asm chunk we just align next_addr onto shdr.sh_addralign value */
#ifdef USE_ASM
			_asm {
				mov ecx, [shdr.sh_addralign]
				test ecx, ecx
				jz short end_align
				mov eax, [next_addr]
				dec ecx
				and eax, ecx
				mov eax, [next_addr]
				jz short end_align
				add eax, ecx
				inc eax
				not ecx
				and eax, ecx
				mov [next_addr], eax
		end_align:
			}
#else
		if ( shdr.sh_addralign > 1 )
		{
		  if ( next_addr & (shdr.sh_addralign - 1) )
	           next_addr = (next_addr & ~(shdr.sh_addralign - 1)) + shdr.sh_addralign;
		}
#endif
		printf("sh_size: 0x%X (next: 0x%X)\n", shdr.sh_size, next_addr);
		/* link */
		printf("sh_link: 0x%X\n", shdr.sh_link);
		/* info */
		printf("sh_info: 0x%X\n", shdr.sh_info);
		/* addralign */
		printf("sh_addralign: 0x%X\n", shdr.sh_addralign);
		/* entsize */
		printf("sh_entsize: 0x%X\n", shdr.sh_entsize);
		}
	}
	/* end of programm */
	fclose(fp);
	return 0;
}
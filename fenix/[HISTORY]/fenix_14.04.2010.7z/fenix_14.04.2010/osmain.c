/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/

#pragma pack(1)
//asm(".intel_syntax noprefix\n");
//gcc -masm-intel

#include "include/aliases.h"

#include "include/asm.h"
#include "include/io.h"

#include "include/systables.h"
#include "include/exception.h"
#include "include/gates.h"
#include "include/task.h"

#include "include/string.h"
#include "include/memory.h"

#include "include/timers.h"
#include "include/cmos.h"
#include "include/clock.h"

#include "include/console.h"
#include "include/ide.h"



Task task0;
Task task1;
Task *current;







void dump( u32 base, u32 n )
{
  CLI();
  u8 *p = (u8*) base;
  u32 i;
  for( i = 0; i != n; ++i )
  {
    prints( u32ToString(p[i],16) );
    printc( ' ' );
  };
  printc( '\n' );
  STI();
};








tchar *keyNames[] = { "",          "ESC",       "1",         "2",         "3",         "4",         "5",         "6",         "7",         "8",
                      "9",         "0",         "-",         "=",         "Backspace", "Tab",       "q",         "w",         "e",         "r",
                      "t",         "y",         "u",         "i",         "o",         "p",         "[",         "]",         "Enter",     "Ctrl",
                      "a",         "s",         "d",         "f",         "g",         "h",         "j",         "k",         "l",         ";",
                      "\'",        "`",         "LShift",    "\\",        "z",         "x",         "c",         "v",         "b",         "n",
                      "m",         ",",         ".",         "/",         "RShift",    "PrtSc",     "Alt",       "Space",     "CapsLk",    "F1",
                      "F2",        "F3",        "F4",        "F5",        "F6",        "F7",        "F8",        "F9",        "F10",       "Pause",
                      "F12",       "71",        "Up",        "73",        "74",        "Left",      "76",        "Right",     "78",        "79",
                      "Down",      "81",        "Insert",    "Delete",    "84",        "85",        "86",        "F11",       "F12",       "89",
                      "90",        "WinKey",    "92",        "WinMenu",   "94",        "95",        "Switch-96", "97",        "98",        "99",
                      "100",       "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE" };

tchar *keyShiftedNames[] = { "",          "ESC",       "!",         "@",         "#",         "$",         "%",         "^",         "&",         "*",
                             "(",         ")",         "_",         "+",         "Backspace", "Tab",       "Q",         "W",         "E",         "R",
                             "T",         "Y",         "U",         "I",         "O",         "P",         "{",         "}",         "Enter",     "Ctrl",
                             "A",         "S",         "D",         "F",         "G",         "H",         "J",         "K",         "L",         ":",
                             "\"",        "~",         "LShift",    "|",         "Z",         "X",         "C",         "V",         "B",         "N",
                             "M",         "<",         ">",         "?",         "RShift",    "PrtSc",     "Alt",       "Space",     "CapsLk",    "F1",
                             "F2",        "F3",        "F4",        "F5",        "F6",        "F7",        "F8",        "F9",        "F10",       "Pause",
                             "F12",       "71",        "Up",        "73",        "74",        "Left",      "76",        "Right",     "78",        "79",
                             "Down",      "81",        "Insert",    "Delete",    "84",        "85",        "86",        "F11",       "F12",       "89",
                             "90",        "WinKey",    "92",        "WinMenu",   "94",        "95",        "Switch-96", "97",        "98",        "99",
                             "100",       "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",
                             "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE",      "MORE" };


extern void onRtc();
__asm__("_onRtc:            \n"    // IRQ8
        "call _doOnRtc      \n"
        "sti                \n"
        "iret               \n");

void doOnRtc()
{
  prints( "[RTC]" );
};







extern void onTimer();
__asm__("_onTimer:          \n"    // IRQ0
        "call _doOnTimer    \n"
        "sti                \n"
        "iret               \n");

void doOnTimer( u32 eip, u32 eflags )
{
  current->tss.eip = eip;
  current->tss.ebp += 12;
  current->tss.esp += 12;
  current->tss.eflags = eflags;

  if( current == &task1 )
  {
    current = &task0;
    asm("ljmp $0x18, $0");
  } else if( current == &task0 ) {
    current = &task1;
    asm("ljmp $0x20, $0");
  } else {
    prints( "<-error->" );
    current = &task1;
  };
};









extern void onKeyboard();
__asm__("_onKeyboard:       \n"    // IRQ1
        "pusha              \n"
        "xor %eax, %eax     \n"
        "inb $0x60, %al     \n"
        "push %eax          \n"
        "call _doOnKeyboard \n"
        "pop %eax           \n"
        "popa               \n"
        "sti                \n"
        "iret               \n");

static u8 shiftState = 0;
void doOnKeyboard( u8 scancode )
{
  //u8 value = rdio8( 0x60 );

  switch( scancode & 0x7F )
  {
  case 1:
    machineReboot();

  case 20:
    printf( "$u.$u.$u $s $u:$u:$u\n", startupDateTime.day, startupDateTime.month, startupDateTime.year, weekDayNames[startupDateTime.weekDay], startupDateTime.hour, startupDateTime.minute, startupDateTime.second );
    return;

  case 83:
    clearScreen( 0x0F );
    return;

  case 42:
  case 54:
    shiftState = !(scancode & 0x80);
    return;

  default:
    if( scancode & 0x80 )  return;
    prints( shiftState ? keyShiftedNames[scancode] : keyNames[scancode] );
  };
};















void setup()
{
  u16 value;
  // ��� �� ������ �����, ��� ��������� ����������� ���������� IRQ
  wrio8( 0x00, 0x21 ); // 0x21 - ������� ���������� ����������
  wrio8( 0x00, 0xA1 ); // 0xA1 - ������� ���������� ����������

  // �������������� ������, ������������ ������� ��������� RAM
  configureRam();

  // ������� initGates() �������������� idttable
  configureGates(); 

  // ������������� ����������� ����������
  setTrapGate( &doOnDivideError, 0x00 );
  setTrapGate( &doOnDebug, 0x01 );
  setTrapGate( &doOnNmi, 0x02 );
  setTrapGate( &doOnBreakpoint, 0x03 );
  setTrapGate( &doOnOverflow, 0x04 );
  setTrapGate( &doOnBoundsExceeded, 0x05 );
  setTrapGate( &doOnInvalidOpcode, 0x06 );
  setTrapGate( &doOnNoX87, 0x07 );
  setTrapGate( &doOnDoubleFault, 0x08 );
  setTrapGate( &doOnX87Overrun, 0x09 );
  setTrapGate( &doOnInvalidTss, 0x0A );
  setTrapGate( &doOnSegmentNotPresent, 0x0B );
  setTrapGate( &doOnStackSegmentFault, 0x0C );
  setTrapGate( &doOnGeneralProtection, 0x0D );
  setTrapGate( &doOnPageFault, 0x0E );
  setTrapGate( &doOnReserved, 0x0F );
  setTrapGate( &doOnX87Fault, 0x10 );
  setTrapGate( &doOnAlignmentCheck, 0x11 );

  for( value = 0x12; value != 0x20; ++value )  setTrapGate( &doOnReserved, value );

  // ������������� ����������� ����������
  setTrapGate( &onRtc, 0x28 );
  setTrapGate( &onTimer, 0x20 );
  setTrapGate( &onKeyboard, 0x21 );

  // ������������� i8253-����������� ����������
  configure8253( I8253_CH0 | I8253_READ_LHB | I8253_MODE3 | I8253_BIN );
  set82530( 0x7FFF );

  // ��� ������� �������������� �������:
  // ������������� ��������� �� �����������,
  // ������� �����, �������� ��� ������� �������
  // ������� - �������� �������
  configureConsole( 0x0F );

  // ��� ������� �������������� ���� ��������� �������:
  // �������� ����� bin ������ bcd, � 24�-������� ������
  configureClock();

  value = rdcmos( CMOS_SECOND );
  while( rdcmos(CMOS_SECOND) == value )  NOP();

  readSystemClock( &startupDateTime );
};













ScreenCharacter *videomem = (ScreenCharacter*) 0xB8000;

void doTask1()
{
  STI();
  u16 n = 200;
  while( --n )
  {
    videomem[69].character++;
    HLT();
  };
  current->exitcode = 0;
};
MAKE_ASM_TASK_CALL( doTask1, entryTask1 );


/*
typedef u8 mutex;

void lock( mutex *m )
{
  __asm__("mov $1, %%al       \n"
          "try:               \n"
          "xchg %%al, (%%edi) \n"
          "test %%al, %%al    \n"
          "jnz try            \n"
          :: "D" (m) );
};

void unlock( mutex *m )
{
  *m = 0;
};
*/




void osmain()
{
  setup();

  printf( "\nCMOS:\n"
          "0x0A:$u\n"
          "0x0B:$u\n"
          "0x0C:$u\n"
          "0x0D:$u\n"
          "0x0E:$u\n"
          "0x0F:$u\n"
          "0x10:$u\n"
          "0x12:$u\n"
          "0x14:$u\n"
          "0x15:$u\n"
          "0x16:$u\n"
          "0x17:$u\n"
          "0x18:$u\n"
          "0x19:$u\n"
          "0x20:$u\n"
          "0x2F:$u\n"
          "0x2E:$u\n"
          "0x33:$u\n",
          rdcmos(0x0A),
          rdcmos(0x0B),
          rdcmos(0x0C),
          rdcmos(0x0D),
          rdcmos(0x0E),
          rdcmos(0x0F),
          rdcmos(0x10),
          rdcmos(0x12),
          rdcmos(0x14),
          rdcmos(0x15),
          rdcmos(0x16),
          rdcmos(0x17),
          rdcmos(0x18),
          rdcmos(0x19),
          rdcmos(0x20),
          rdcmos(0x2F),
          rdcmos(0x2E),
          rdcmos(0x33) );

  prints("---------------------------------[OS Fenix (c)]---------------------------------\n");
  printf( "ram:$u\n", memoryTotal );

  gdtable[3].a16 = sizeof(Task) & 0x00FFFF - 1;         // ���������, ��� ����� �� ������ 64 K
  gdtable[3].f8  = 0x89;
  gdtable[3].g8  = 0x00;
  gdtable[3].b16 = ((u32)&task0) & 0x0000FFFF;          // ������� ����� ������ ����
  gdtable[3].e8  = (((u32)&task0) & 0x00FF0000) >> 16;  // ������� ���� �������� �����
  gdtable[3].h8  = (((u32)&task0) & 0xFF000000) >> 24;  // ������� ���� �������� �����




  task1.tss.es = 0x10;
  task1.tss.ds = 0x10;
  task1.tss.ss = 0x10;
  task1.tss.fs = 0x10;
  task1.tss.gs = 0x10;
  task1.tss.cs = 0x08;

  task1.tss.ss0 = 0x10;
  task1.tss.ss1 = 0x10;
  task1.tss.ss2 = 0x10;

  task1.tss.ebp = 0xFFFF;
  task1.tss.esp = 0xFFFF;

  task1.tss.eflags = 0;

  task1.tss.cr3 = 0;
  task1.tss.eip = (u32) &entryTask1;
  task1.tss.iomap = sizeof(Tss);
  task1.tss.debug = 0;




  gdtable[4].a16 = sizeof(Task) & 0x00FFFF - 1;         // ���������, ��� ����� �� ������ 64 K
  gdtable[4].f8  = 0x89;
  gdtable[4].g8  = 0x00;
  gdtable[4].b16 = ((u32)&task1) & 0x0000FFFF;          // ������� ����� ������ ����
  gdtable[4].e8  = (((u32)&task1) & 0x00FF0000) >> 16;  // ������� ���� �������� �����
  gdtable[4].h8  = (((u32)&task1) & 0xFF000000) >> 24;  // ������� ���� �������� �����


  asm("ltr %%ax      " :: "a" (0x18) );

  current = &task1;
  asm("ljmp $0x20, $0");

  STI();
  while(1)
  {
    ++videomem[9].character;
    HLT();
  };
};

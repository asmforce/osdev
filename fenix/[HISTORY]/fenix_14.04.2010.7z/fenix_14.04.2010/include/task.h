/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_TASK_H
#define FENIX_TASK_H

#include "aliases.h"

typedef struct
{
  u16 link;
  unsigned:16;

  u32 esp0;
  u16 ss0;
  unsigned:16;

  u32 esp1;
  u16 ss1;
  unsigned:16;

  u32 esp2;
  u16 ss2;
  unsigned:16;

  u32 cr3;
  u32 eip;
  u32 eflags;

  u32 eax;
  u32 ecx;
  u32 edx;
  u32 ebx;

  u32 esp;
  u32 ebp;
  u32 esi;
  u32 edi;

  u16 es;
  unsigned:16;
  u16 cs;
  unsigned:16;
  u16 ss;
  unsigned:16;
  u16 ds;
  unsigned:16;
  u16 fs;
  unsigned:16;
  u16 gs;
  unsigned:16;

  u16 ldtr;
  unsigned:16;

  unsigned debug:1;
  unsigned:15;
  u16 iomap;
} Tss;


typedef struct
{
  Tss tss;
  u32 exitcode;
} Task;

#endif

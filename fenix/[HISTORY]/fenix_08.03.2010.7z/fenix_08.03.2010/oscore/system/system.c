#define cli() asm("cli")
#define sti() asm("sti")
#define nop() asm("nop")
#define hlt() asm("hlt")


void inline reboot()
{
  asm( "MOV $0xFE, %AL \n OUT %AL, $0x64" );
}

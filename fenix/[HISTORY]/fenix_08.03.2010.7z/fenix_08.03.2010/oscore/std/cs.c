u32 cslen( const char *cs )
{
  u32 length = (u32)cs;
  while( cs )  ++cs;
  return(length - (u32)cs);
};

u32 csToU32( const char *cs )
{
  u32  res = 0;
  while( cs )
  {
    res *= 10;
    res += *cs - '0';
    ++cs;
  }
  return res;
};

static char buffer[11] = {'0','0','0','0','0','0','0','0','0','0','\0'};
const char *toCs( u32 num, u8 radix )
{
  char *pbuffer = buffer+9;
  u32 ost;

  do
  {
    ost = num % radix;
    if( ost < 10 )
    {
      *pbuffer = '0' + ost;
    } else {
      *pbuffer = 'A' + ost;
    };
    --pbuffer;
  } while( num /= radix );
  return pbuffer+1;
};

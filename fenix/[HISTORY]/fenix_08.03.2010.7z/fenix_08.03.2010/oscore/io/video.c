#define VIDEO_TEXT_BEG  0xB8000
#define VIDEO_TEXT_END  ((0xB8000 + (25*80))*2+1)
#define VIDEO_GRAPH_BEG 0xA0000



static u8 *videoBuffer = (u8*) 0xB8000;


void outToConsole( const char *cs )
{
  while( *cs )
  {
    *videoBuffer = *cs;
    ++cs;
    videoBuffer += 2;
  };
};

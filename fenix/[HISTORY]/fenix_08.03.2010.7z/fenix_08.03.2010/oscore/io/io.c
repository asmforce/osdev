extern void inline oPortByte( char value, unsigned short port )
{
  __asm__ __volatile__ ("outb %%al,%%dx"::"a" ((char) value),"d" ((unsigned short) port));
}

extern unsigned int inline iPortByte( unsigned short port )
{
  unsigned int v;
  __asm__ __volatile__ ("inb %%dx,%%al":"=a" (v):"d" ((unsigned short) port),"0" (0));
  return v;
}

#include "aliases.c"
#include "io/io.c"
#include "io/video.c"
#include "system/system.c"
#include "std/cs.c"


void osMain()
{
  outToConsole( toCs( 5657, 10 ) );
  cli();
  hlt();

  u32 i;
  for( i = 0; i != 100; ++i )
    asm("hlt");
  reboot();
}

void osStart()
{
  osMain();
}

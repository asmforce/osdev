/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_RTC_C
#define FENIX_RTC_C

#include "../include/aliases.h"
#include "../include/utility.h"
#include "../include/console.h"
#include "../include/cmos.h"
#include "../include/rtc.h"

const tchar *weekDayNames[] = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

void readRtc( DateTime *datetime )
{
  datetime->year    = BCDToBin8( rdcmos(0x32) ) * 100;    // 0x32 - ��� � BCD �������
  datetime->year   += rdcmos( 0x09 );

  datetime->month   = rdcmos( 0x08 );
  datetime->day     = rdcmos( 0x07 );

  datetime->weekDay = rdcmos( 0x06 );

  datetime->hour    = rdcmos( 0x04 );
  datetime->minute  = rdcmos( 0x02 );
  datetime->second  = rdcmos( 0x00 );
};

#endif

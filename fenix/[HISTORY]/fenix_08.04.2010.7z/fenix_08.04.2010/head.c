/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
void osentry()
{
  osmain();
};

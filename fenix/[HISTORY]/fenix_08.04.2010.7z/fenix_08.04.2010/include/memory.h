/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_MEMORY_H
#define FENIX_MEMORY_H

#include "aliases.h"

extern const u32 memoryTotal;

void initRam();

static inline void *ramcpy( void *to, const void *from, u32 n )
{
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep movsd\n\t"
      "movl %%ebx, %%ecx\n\t"
      "andl $3, %%ecx\n\t"
      "rep movsb"
      ::"S" (from), "D" (to), "c" (n) );
  return to;
};

static inline void *ramset( void *to, u8 c, u32 n )
{
  u32 num = c;
  asm("cld\n\t"
      "movl %%ecx, %%ebx\n\t"
      "shrl $2, %%ecx\n\t"
      "rep stosl\n\t"
      "movl %%ebx, %%ecx\n\t"
      "andl $3, %%ecx\n\t"
      "rep stosb"
      ::"D" (to), "a" (num | (num << 8) | (num << 16) | (num << 24)), "c" (n) );
  return to;
};

static inline i8 ramcmp( const void *p1, const void *p2, u32 n )
{
  i8 result;
  asm("cld \n\t"
      "repe cmpsb \n\t"
      "decl %%esi \n\t"
      "decl %%edi \n\t"
      "movb (%%edi), %%al \n\t"
      "subb (%%esi), %%al \n\t"
      :"=S" (p2), "=D" (p1), "=a" (result)
      :"S" (p2), "D" (p1), "c" (n) );
  return result;
};

#endif

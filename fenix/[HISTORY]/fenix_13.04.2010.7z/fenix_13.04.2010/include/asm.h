/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_ASM_H
#define FENIX_ASM_H

#include "aliases.h"

#define CLI()    asm("cli")
#define STI()    asm("sti")
#define NOP()    asm("nop")
#define HLT()    asm("hlt")

#define PUSHA()  asm("pusha")
#define POPA()   asm("popa")
#define PUSHF()  asm("pushf")
#define POPF()   asm("popf")

#define machineReboot() asm("mov $0xFE, %al    \n"  \
                            "out %al, $0x64    \n"  \
                            "mark: \t jmp mark \n")

#define CPUID( _eax_, _ebx_, _ecx_, _edx_ )  asm("cpuid":"=a"(_eax_),"=b"(_ebx_),"=c"(_ecx_),"=d"(_edx_):"a"(_eax_))
 
#define MAKE_ASM_CALL( cname, asmname )   \
extern void asmname();                    \
__asm__("_" #asmname     ":\n"            \
        "call _" #cname  " \n"            \
        "iret              \n"); 

#define MAKE_ASM_CALL_ERROR( cname, asmname )   \
extern void asmname();                          \
__asm__("_" #asmname     ":\n"                  \
        "call _" #cname  " \n"                  \
        "add $4, %esp      \n"                  \
        "iret              \n");
 
#define MAKE_ASM_TASK_CALL( cname, asmname )   \
extern void asmname();                         \
__asm__("_" #asmname     ":\n"                 \
        "call _" #cname  " \n"                 \
        "1:                \n"                 \
        "hlt               \n"                 \
        "jmp 1b            \n");

#endif

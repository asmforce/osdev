/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CMOS_H
#define FENIX_CMOS_H

#include "aliases.h"
#include "io.h"

u8 rdcmos( u8 cell );
void wrcmos( u8 value, u8 cell );

#endif

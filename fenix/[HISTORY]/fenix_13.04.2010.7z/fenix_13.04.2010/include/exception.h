/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_EXCEPTION_H
#define FENIX_EXCEPTION_H

#include "aliases.h"
#include "console.h"
#include "asm.h"

void doOnDivideError()
{
  PUSHA();
  prints( "<exc:int0:divide-error>\n" );
  POPA();
};

void doOnDebug()
{
  PUSHA();
  prints( "<exc:int1:debug>\n" );
  POPA();
};

void doOnNmi()
{
  PUSHA();
  prints( "<exc:int2:nmi>\n" );
  POPA();
};

void doOnBreakpoint()
{
  PUSHA();
  prints( "<exc:int3:breakpoint>\n" );
  POPA();
};

void doOnOverflow()
{
  PUSHA();
  prints( "<exc:int4:overflow>\n" );
  POPA();
};

void doOnBoundsExceeded()
{
  PUSHA();
  prints( "<exc:int5:bounds-exceeded>\n" );
  POPA();
};

void doOnInvalidOpcode()
{
  PUSHA();
  prints( "<exc:int6:invalid-opcode>\n" );
  POPA();
};

void doOnNoX87()
{
  PUSHA();
  prints( "<exc:int7:no-x87>\n" );
  POPA();
};

void doOnDoubleFault( u32 errcode )
{
  PUSHA();
  prints( "<exc:int8:double-fault>\n" );
  POPA();
};

void doOnX87Overrun()
{
  PUSHA();
  prints( "<exc:int9:x87-overrun>\n" );
  POPA();
};

void doOnInvalidTss( u32 errcode )
{
  PUSHA();
  prints( "<exc:int0A:invalid-tss>\n" );
  POPA();
};

void doOnSegmentNotPresent( u32 errcode )
{
  PUSHA();
  prints( "<exc:int0B:segment-not-present>\n" );
  POPA();
};

void doOnStackSegmentFault( u32 errcode )
{
  PUSHA();
  prints( "<exc:int0C:stack-segment-fault>\n" );
  POPA();
};

void doOnGeneralProtection( u32 errcode )
{
  PUSHA();
  prints( "<exc:int0D:general-protection>\n" );
  POPA();
};

void doOnPageFault( u32 errcode )
{
  PUSHA();
  prints( "<exc:int0E:page-fault>\n" );
  POPA();
};

void doOnReserved()
{
  PUSHA();
  prints( "<exc:intXX:intel-reserved>\n" );
  POPA();
};

void doOnX87Fault()
{
  PUSHA();
  prints( "<exc:int10:x87-fault>\n" );
  __asm__("fnclex");
  POPA();
};

void doOnAlignmentCheck( u32 errcode )
{
  PUSHA();
  prints( "<exc:int11:alignment-check>\n" );
  POPA();
};

MAKE_ASM_CALL( doOnDivideError, onDivideError );
MAKE_ASM_CALL( doOnDebug, onDebug );
MAKE_ASM_CALL( doOnNmi, onNmi );
MAKE_ASM_CALL( doOnBreakpoint, onBreakpoint );
MAKE_ASM_CALL( doOnOverflow, onOverflow );
MAKE_ASM_CALL( doOnBoundsExceeded, onBoundsExceeded );
MAKE_ASM_CALL( doOnInvalidOpcode, onInvalidOpcode );
MAKE_ASM_CALL( doOnNoX87, onNoX87 );
MAKE_ASM_CALL_ERROR( doOnDoubleFault, onDoubleFault );
MAKE_ASM_CALL( doOnX87Overrun, onX87Overrun );
MAKE_ASM_CALL_ERROR( doOnInvalidTss, onInvalidTss );
MAKE_ASM_CALL_ERROR( doOnSegmentNotPresent, onSegmentNotPresent );
MAKE_ASM_CALL_ERROR( doOnStackSegmentFault, onStackSegmentFault );
MAKE_ASM_CALL_ERROR( doOnGeneralProtection, onGeneralProtection );
MAKE_ASM_CALL_ERROR( doOnPageFault, onPageFault );
MAKE_ASM_CALL( doOnReserved, onReserved );
MAKE_ASM_CALL( doOnX87Fault, onX87Fault );
MAKE_ASM_CALL_ERROR( doOnAlignmentCheck, onAlignmentCheck );

#endif

/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_TIMERS_H
#define FENIX_TIMERS_H

#include "aliases.h"
#include "io.h"

#define PIT_MODE 0x43
#define PIT_CH0  0x40
// #define PIT_CH1  0x41 // ����� ����������� ��� ����������� ������������ ������
#define PIT_CH2  0x42

void inline writeTimer0( u16 counter )
{
  wrio8( (counter) & 0xFF, PIT_CH0 );
  NOP();
  wrio8( (counter) >> 8, PIT_CH0 );
};

void inline writeTimer2( u16 counter )
{
  wrio8( (counter) & 0xFF, PIT_CH2 );
  NOP();
  wrio8( (counter) >> 8, PIT_CH2 );
};



void inline initTimer0( u8 mode, u16 counter )
{
  wrio8( 0x30 | (((mode)&0x07)<<1), PIT_MODE );
  writeTimer0( counter );
};

void inline initTimer2( u8 mode, u16 counter )
{
  wrio8( 0xB0 | (((mode)&0x07)<<1), PIT_MODE );
  writeTimer2( counter );
};



u16 inline readTimer0()
{
  u16 counter = rdio8( PIT_CH0 );
  NOP();
  return counter | ((u16)rdio8(PIT_CH0) << 8);
};

u16 inline readTimer2()
{
  u16 counter = rdio8( PIT_CH2 );
  NOP();
  return counter | ((u16)rdio8(PIT_CH2) << 8);
};

#endif

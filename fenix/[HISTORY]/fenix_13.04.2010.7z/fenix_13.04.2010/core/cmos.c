/*
* os fenix
* asmforce (nickname) asmforce@ukr.net
* 2010
*/
#ifndef FENIX_CMOS_C
#define FENIX_CMOS_C

#include "../include/aliases.h"
#include "../include/asm.h"
#include "../include/io.h"
#include "../include/cmos.h"

u8 rdcmos( u8 cell )
{
  wrio8( cell, 0x70 );
  NOP();
  return rdio8( 0x71 );
};

void wrcmos( u8 value, u8 cell )
{
  wrio8( cell, 0x70 );
  NOP();
  wrio8( value, 0x71 );
};

#endif

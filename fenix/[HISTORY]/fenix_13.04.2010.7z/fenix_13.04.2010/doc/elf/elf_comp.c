#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>

#pragma pack(1) 
#include "elf.h"

/* ELF compact
 * Red Plait (redplait@usa.net) 6-IV-2000
 */

const char *elf_types[] = {
	"Relocatable file",
	"Executable file",
	"Shared object file",
	"Core file"
};

#define SUFFIX_LEN	5
#define RP_SIGN1	0x50646552
#define RP_SIGN2	0x7469616C

const char *suffix = ".cmpt";

int
check_my_ELF(char *mapped)
{
  struct Elf32_Hdr *hdr = (struct Elf32_Hdr *)mapped;
  if ( hdr->e_type != 2 )
  {
    fprintf(stderr,"I can compact only executable files, but this is %s\n",
 	   elf_types[hdr->e_type-1]);
    return 0;
  }
  if ( !hdr->e_phnum )
  {
     fprintf(stderr, "No programm header ! Does it even run ?\n");
     return 0;
  }
  return 1;
}

int
check_ELF(char *mapped, size_t size)
{
  struct Elf32_Hdr *hdr = (struct Elf32_Hdr *)mapped;
  if ( size < sizeof(struct Elf32_Hdr) )
  {
    fprintf(stderr, "Too small to be ELF\n");
    return 0;
  }
  if ( hdr->EI_MAG0 != ELFMAG0 ||
       hdr->EI_MAG1 != ELFMAG1 ||
       hdr->EI_MAG2 != ELFMAG2 ||
       hdr->EI_MAG3 != ELFMAG3 )
  {
    fprintf(stderr, "Bad signature\n");
    return 0;
  }
  if ( hdr->EI_CLASS == 2 )
  {
    fprintf(stderr, "64bit ELF dont supported (yet ?)\n");
    return 0;
  }
  if ( hdr->EI_CLASS != 1 )
  {
    fprintf(stderr, "Unknown EI_CLASS %d\n", hdr->EI_CLASS);
    return 0;
  }
  /* check for data encoding */
  if ( hdr->EI_DATA != 1 &&
       hdr->EI_DATA != 2 )
  {
    fprintf(stderr, "Bad EI_DATA %d\n", hdr->EI_DATA);
    return 0;
  }
  if ( hdr->EI_DATA != 1 )
  {
    fprintf(stderr, "LSB data encoding not supported (yet)\n");
    return 0;
  }
  /* check for e_type */
  if ( hdr->e_type < 1 || hdr->e_type > 4 )
  {
    fprintf(stderr, "Unknown e_type %d\n", hdr->e_type);
    return 0;
  }
  if ( hdr->e_ehsize != sizeof(*hdr) )
  {
    fprintf(stderr, "Bad e_ehsize %d, must be %d\n",
     hdr->e_ehsize, sizeof(*hdr) );
    return 0;
  }
  if ( hdr->e_phnum && hdr->e_phentsize != sizeof(struct Elf_phdr) )
  {
    fprintf(stderr, "Bad e_phentsize %d, must be %d\n",
	    hdr->e_phentsize, sizeof(struct Elf_phdr) );
    return 0;
  }
  if ( hdr->e_shnum && hdr->e_shentsize != sizeof(struct Elf_shdr) )
  {
    fprintf(stderr,"Bad e_shentsize %d, must be %d\n",
	   hdr->e_shentsize, sizeof(struct Elf_shdr) );
    return 0;
  }
  return 1;
}

int
main_processing(char *mapped, size_t size, FILE *fp)
{
  struct Elf32_Hdr *hdr = (struct Elf32_Hdr *)mapped;
  struct Elf_phdr *phdr;
  size_t curr, max = 0;
  unsigned long *fake;
  int i;
  
  phdr = (struct Elf_phdr *)(mapped + hdr->e_phoff);
  for ( i = 0; i < hdr->e_phnum; i++, phdr++ )
  {
#ifdef RP_DEBUG
 printf("p_Off 0x%X, p_filesz 0x%X\n", phdr->p_offset, phdr->p_filesz);
#endif
    curr = phdr->p_offset + phdr->p_filesz;
    if ( curr > size )
    {
      fprintf(stderr, "PSection [%d]: end offset(0x%X) > filesize(0x%X)\n",
        curr, size );
      return 10;
    }
    if ( curr > max )
      max = curr;
  }

  fake = (unsigned long *)(&hdr->e_ident[8]);
  if ( ! *fake )
  {
   *fake = RP_SIGN1;
   *(fake + 1) = RP_SIGN2;
  }
  hdr->e_shoff = 0;
  hdr->e_shnum = (Elf_word)0;
  hdr->e_shentsize = (Elf_word)0;
  hdr->e_shstrndx = (Elf_word)0;
  if ( max != fwrite(mapped, 1, max, fp) )
  {
    fprintf(stderr,"Cannot write 0x%X bytes\n", max);
    return 11;
  }
  return 0;
}

int
do_it(char *mapped, size_t size, char *new_name)
{
  FILE *fp;
  int res;
  /* first check that we have acceptable ELF */
  if ( ! check_ELF(mapped, size) || !check_my_ELF(mapped) )
   return 5;
  /* try to create output file */
  if ( NULL == ( fp = fopen(new_name, "wb") ) )
  {
   fprintf(stderr, "Cannot create output file %s\n", new_name);
   return 6;
  }
  res = main_processing(mapped, size, fp);
  fclose(fp);
  if ( res )
   unlink(new_name);
  return res;
}

int
process_file(char *name)
{
  char *new_name = NULL;
  int len = strlen(name);
  FILE *fp = NULL;
  struct stat st;
  char *mapped = NULL;
  int res;

  if ( 0 != stat(name, &st) )
  {
    fprintf(stderr,"Cannot stat %s\n", name);
    return 1;
  }
  if ( NULL == (fp = fopen(name, "rb")) )
  {
    fprintf(stderr, "Cannot open %s\n", name);
    return 2;
  }
  mapped = (char *)malloc(st.st_size);
  if ( mapped == NULL )
  {
   fclose(fp);
   fprintf(stderr, "Cannot malloc enough room (0x%X bytes) for file content\n",
    st.st_size);
   return 3;
  }
  if ( st.st_size != fread(mapped, 1, st.st_size, fp) )
  {
    free(mapped);
    fclose(fp);
    fprintf(stderr,"Cannot read file content\n");
    return 4;
  }
  fclose(fp);
  if ( NULL == ( new_name = (char *)malloc(len + 1 + SUFFIX_LEN) ) )
  {
      fprintf(stderr, "Cannot get memory for new name (0x%X bytes)\n",
        len + 1 + SUFFIX_LEN );
      res = 4;
  } else {
    strcpy(new_name, name);
    strcpy(new_name + len, suffix);
    res = do_it(mapped, st.st_size, new_name);
  }
  if ( NULL != mapped )
   free(mapped);
  if ( NULL != new_name )
   free(new_name);
  return res;
}

int
main(int argc, char **argv)
{
  int i;
  if ( argc != 2 )
  {
    fprintf(stderr, "Usage: elf_compact <filename> ...\n");
    exit(1);
  }
  for ( i = 1; i < argc; i++ )
  {
    process_file(argv[i]);
  }
  return 0;
}